#!/system/bin/sh

ksud kernel nuke-ext4-sysfs /data/adb/modules/meta-overlayfs/mnt
